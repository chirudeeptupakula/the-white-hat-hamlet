# The White Hat Hamlet
In this project we have made a webiste and indulged "Recent cyber crimes","statistics of cyber crimes","Q & A forum" and also to make people aware of cyber crimes.
"https://hiranmayee1123.github.io/The-White-Hat-Hamlet/index.html" This is the link of our website and we hosted it through github-pages.
# Here is a detailed explanation about our website..

# 1.This is how our home page looks like...You can navigate to menu bars and see the related topic!!

![image](https://user-images.githubusercontent.com/62197337/112629101-dd3e1900-8e59-11eb-9e3f-b0b8d2960bc3.png)

# 2.If you scroll down you can know more about our website and some interesting stuff!!

![image](https://user-images.githubusercontent.com/62197337/112629306-25f5d200-8e5a-11eb-8782-28e867eba3af.png)

# 3.You can see the recent cyber crimes in this section, you can click on the image and know more information about it!!

![image](https://user-images.githubusercontent.com/62197337/112629723-ac121880-8e5a-11eb-89ef-f28a305ba787.png)

# 4.You can see all the statistics in the graphs portal!!

![image](https://user-images.githubusercontent.com/62197337/112630038-1460fa00-8e5b-11eb-84ec-6939c99b70c3.png)

# 5. We have created a question and answer portal in which questions and answers related to cyber crimes which are gathered...we have displayed that if people login,they can ask question or answer the question.

![image](https://user-images.githubusercontent.com/62197337/112630180-3fe3e480-8e5b-11eb-8510-12a8812a3e02.png) 

## 6.Here is a sample login form

![image](https://user-images.githubusercontent.com/62197337/112630684-f2b44280-8e5b-11eb-8205-c5404039e426.png)

# This is all about our website, Hope You Like it.... 😊!!

